(function ($) {
  function check_payment() {
    var which = $('input[name^="payment_method"]:checked').val();

    if (which == "woocommerce-gateway-cryptoalgo") {
      $("#root").show();
      $("#place_order").hide();
    } else {
      $("#root").attr("style", "display: none !important");
      $("#place_order").show();
    }
  }
  // check_payment();

  $("form.checkout").on("change", 'input[name^="payment_method"]', function () {
    check_payment();
  });

  $('form.checkout').on("change", '.cryptoalgo_options input[name="cryptoalgo_option"]', function(e){
    console.log('CHnage');
     if(!e.isTrigger){
      $(document.body).trigger("update_checkout");
      $('#algopay-btn').attr("disabled", "disabled");
     }

  });

  jQuery(document).on("updated_checkout", function () {
    check_payment();
    document.dispatchEvent(new Event("render-payment")); 

  });

//   $("form.checkout").on("change", function () {
//     $('#algopay-btn').attr("disabled", "disabled");
// });



})(jQuery);
