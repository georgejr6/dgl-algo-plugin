<?php

class CryptoAlgo_Validator {

    public static function validate_payment($transaction, $assest_id ,$order) {
        if($assest_id == 0 ){
            $transaction = $transaction['payment-transaction'];
        }else{
            $transaction = $transaction['asset-transfer-transaction'];
        }

        if(empty($transaction) || empty($order)) {
            return false;
        }
    
        $transaction_amount = (int)($transaction['amount']/1000000);

        // Validate transaction
        // $assest_id = self::get_assest_id();
        $amount = get_exchange_rate_of_given_assest($order->get_total(), $assest_id);
        $ex_amount = (int)$amount['price'];
        echo $transaction_amount."<Br>";
        echo $ex_amount."<Br>";
        if($transaction_amount != $ex_amount) {
          
            return false;
        }
        
        // Validate Assest in which customer pay
        if($assest_id != 0 ){
            if($transaction['asset-id'] != $assest_id) {
                return false;
            }
        }  

        // Validate wallet receiver
        $wallet_address = self::get_wallet_address();
        if($transaction['receiver'] != $wallet_address) {
            return false;
        }

        return true;
    }

    public static function get_wallet_address() {
        $options = get_option('woocommerce_woocommerce-gateway-cryptoalgo_settings');

        if(isset($options['wallet']) && !empty($options['wallet'])) {
            return $options['wallet'];
        }

        return false;
    }

    public static function get_assest_id() {
        $options = get_option('woocommerce_woocommerce-gateway-cryptoalgo_settings');

        if(isset($options['assest']) && !empty($options['assest'])) {
            return $options['assest'];
        }

        return false;
    }
}


?>
