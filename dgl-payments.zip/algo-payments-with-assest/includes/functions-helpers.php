<?php 

/**
 * General functions for overall usefulness
 * 
 */

// Exit if accessed directly
if( ! defined( 'ABSPATH' ) ) {
	exit;
}



/**
 * 
 *   Fetch the exchange  rated
 * 
 */

function get_exchange_rate_of_given_assest($amount, $asset_id){
        $return_res = array();
        if($amount == 0){
            $return_res['status'] = 1;
            $return_res['price'] = 0;
            return $return_res;
        }
         

        if (get_transient('crypto_algo_exchange_rate_'.$asset_id)) {

          $Exchange_rate = get_transient('crypto_algo_exchange_rate_'.$asset_id);

           $assest_price = $amount/$Exchange_rate;
           $return_res['status'] = 1;
           $return_res['price'] = $assest_price;
           return $return_res;


        }
        
     
      $api_url = 'https://free-api.vestige.fi/asset/'.$asset_id.'/price?currency=USD';
      if($asset_id == 0){
        $api_url  = 'https://free-api.vestige.fi/currency/USD/price';
      }

      $response = wp_remote_get( $api_url, array('timeout'=> 45) );

      if ( is_wp_error( $response )  OR  200 !== wp_remote_retrieve_response_code( $response ) ) {
       
        $return_res['status'] = 0;
        $return_res['error'] = "Something went wrong";

         echo json_encode($return_res);
      }


      if ( 200 === wp_remote_retrieve_response_code( $response ) ) {
          $return_res['status'] = 1;
          $body = wp_remote_retrieve_body($response );
          $data = json_decode( $body , true);

          $Exchange_rate = $data['price'];

          set_transient( 'crypto_algo_exchange_rate_'.$asset_id, $Exchange_rate, 10 * MINUTE_IN_SECONDS);
          
           $assest_price = $amount/$Exchange_rate;

           $return_res['status'] = 1;
           $return_res['price'] = $assest_price;

           return $return_res;
          
             
      }







}


function is_product_can_be_buy_with_crypto_algo($product){
     $check = false;
     if ( is_object( $product ) ) {
			$product_id = $product->get_id();
      if($product->get_type() == 'variation' ){
			$product_id = $product->get_parent_id();

      }
      
			$crypto_alogo_product = get_post_meta( $product_id, '_cryptoalgo_product', true );
			if ( 'yes' === $crypto_alogo_product ) {
				$check= true;
			}
		}

    return $check;




}


function is_force_pay_enable_on_product($product){
  $check = false;
  if ( is_object( $product ) ) {
   $product_id = $product->get_id();
   if($product->get_type() == 'variation' ){
   $product_id = $product->get_parent_id();

   }
   
   $crypto_alogo_product = get_post_meta( $product_id, '_cryptoalgo_force', true );
   if ( 'yes' === $crypto_alogo_product ) {
     $check= true;
   }
 }

 return $check;




}


function get_cryptoalgo_gateway_settings(){

   return get_option('woocommerce_woocommerce-gateway-cryptoalgo_settings');

}

/**
 * 
 *  get the crypto price html function for simple product
 * 
 */

 function get_crypto_algo_price_html($price, $unit){

     return  '<span class="woocommerce-Price-amount amount"><bdi>'.number_format($price,5, '.', '').'
     <span class="woocommerce-Price-currencySymbol">'.$unit.'</span></bdi>
     </span>';
 }

 /**
 * 
 *  get the crypto price html function for variable products
 * 
 */

function get_crypto_algo_price_range_html($min, $max,$unit){

  return  '<span class="woocommerce-Price-amount amount"><bdi>'.$min.'
  <span class="woocommerce-Price-currencySymbol">'.$unit.'</span></bdi>
  </span> – <span class="woocommerce-Price-amount amount"><bdi>'.$max.'
  <span class="woocommerce-Price-currencySymbol">'.$unit.'</span></bdi>
  </span>';
}



function crypto_algo_change_product_price_display($price_html, $product ) {
  
  $gateway_Settings = get_cryptoalgo_gateway_settings();

  if(is_product_can_be_buy_with_crypto_algo($product)){

    if( $product->is_type( 'variable' ) ) {
      $min = $product->get_variation_regular_price('min');
      $max = $product->get_variation_regular_price('max');
      $DGL_price_min  =   get_exchange_rate_of_given_assest($min, $gateway_Settings['assest']);
      $DGL_price_max  =   get_exchange_rate_of_given_assest($max, $gateway_Settings['assest']);
      $DGL_price_min  =   number_format($DGL_price_min['price'],5, '.', '');
      $DGL_price_max  =   number_format($DGL_price_max['price'],5, '.', '');

      $price_h  =  get_crypto_algo_price_range_html($DGL_price_min, $DGL_price_max, $gateway_Settings['unit']);


      if($gateway_Settings['algo_enabled']  == "yes"){

        $Algo_price_min  =   get_exchange_rate_of_given_assest($min, 0);
        $Algo_price_max  =   get_exchange_rate_of_given_assest($max, 0);
        $Algo_price_min  =   number_format($Algo_price_min['price'],5, '.', '');
        $Algo_price_max  =   number_format($Algo_price_max['price'],5, '.', '');

        $price_h  .= "<br>".get_crypto_algo_price_range_html($Algo_price_min, $Algo_price_max, '$Algo');
      }

    }else{
      
      $amount = $product->get_price();
      $DGL_price  =   get_exchange_rate_of_given_assest($amount, $gateway_Settings['assest']);
      

      $price_h  = get_crypto_algo_price_html($DGL_price['price'], $gateway_Settings['unit']);
      if($gateway_Settings['algo_enabled']  == "yes"){
       $Algo_price  =   get_exchange_rate_of_given_assest($amount, 0);
      $price_h  .= "<br>".get_crypto_algo_price_html($Algo_price['price'], '$Algo');
      }


    }


    $price_html .=  "<br>".$price_h;
  }
  
  return $price_html;
}



function crypto_algo_filter_woocommerce_cart_item_price( $wc, $cart_item, $cart_item_key ){
  $product = $cart_item['data'];
  if(is_product_can_be_buy_with_crypto_algo($product)){

  $gateway_Settings = get_cryptoalgo_gateway_settings();
  $DGL_price  =   get_exchange_rate_of_given_assest($cart_item['line_total'], $gateway_Settings['assest']);
  $price_h = $wc."<br>".get_crypto_algo_price_html($DGL_price['price'], $gateway_Settings['unit']);

  if($gateway_Settings['algo_enabled']  == "yes" ){

   $Algo_price  =   get_exchange_rate_of_given_assest($cart_item['line_total'], 0);
   $price_h .= "<br>".get_crypto_algo_price_html($Algo_price['price'], '$Algo');

  }

   return $price_h;

  }else{
    return  $wc;

  }

}


function check_type_of_products_in_cart(){

  $cart_obj = WC()->cart;

  $return_array = array('c' => false, 'nc' => false, 'fpay' => false);

  if(!is_admin()){  

      foreach ( $cart_obj->get_cart() as $cart_item_key => $cart_item ) {
        $product = $cart_item['data'];
      
          if(is_product_can_be_buy_with_crypto_algo($product)){
             $return_array['c'] = true;
          
            }else{  $return_array['nc'] = true;}


          if(is_force_pay_enable_on_product($product)){
            $return_array['fpay'] = true;
     
          }

        }
        

   }

    return $return_array;

}


function crypto_algo_notice(){

    // echo "<pre>";
    // print_r(WC()->cart->get_cart());
    // echo "</pre>";
  
  $check_array = check_type_of_products_in_cart();
  
  if($check_array['c'] AND  $check_array['nc']){

   wc_print_notice( __('To pay in Crypto Currency only keep Crypto products in the Cart'), 'notice' );

  }


}


function is_cart_has_both_type_of_products_check_crypto($gateways){
     
     $gateway_names = array_keys($gateways);

     $check_array = check_type_of_products_in_cart();

  
      if($check_array['c'] AND  $check_array['nc']  ){
        unset($gateways['woocommerce-gateway-cryptoalgo']);
      }

      if(!$check_array['c']  AND $check_array['nc'] ){
        unset($gateways['woocommerce-gateway-cryptoalgo']);
      }
      
      if($check_array['fpay'] AND  $check_array['nc']) {
          $gateways = array();
          echo "<style>.wc-proceed-to-checkout a, #place_order{ display:none !important;}</style>";
      }

      // if($check_array['fpay'] AND  $check_array['nc']) {
      //   foreach($gateway_names as $key){
      //         if($key != 'woocommerce-gateway-cryptoalgo'){
      //         unset($gateways[$key]);
      //         }
        
      //       }
      //   }

      if($check_array['fpay'] AND  !$check_array['nc']) {
          foreach($gateway_names as $key){
                if($key != 'woocommerce-gateway-cryptoalgo'){
                  unset($gateways[$key]);
                }
            
          }
      }
  
  
   return $gateways;
  

}




//  Payment Button 



function cryptoalgo_javascript_footer() {
  ?>
  
      <script>
            jQuery(function($){
              $(document).on('click','#crypto_payment_btn', function(evt){
                evt.preventDefault();
                    let variant_id = "";
                    let parent_form = $(this).parents('form.cart');
                 
                    if(parent_form.hasClass('variations_form')){
                      variant_id = $('input[name="variation_id"]',parent_form).attr('value');
                    }else{
                      variant_id = $('button[name="add-to-cart"]',parent_form).val();

                    }
                   
                   let quantity =  $('input[name="quantity"]', parent_form).val();
                    if(variant_id != '' && variant_id != undefined && variant_id != 0){
                      var url = '<?php echo wc_get_checkout_url() ?>?add-to-cart=' + variant_id + '&quantity=' + quantity;
                    //   window.location.href = url;
                      parent_form.find('button[type="submit"]').trigger('click');

                    //   console.log(url);

                    }
                    


              });



            });



        
      </script>
      <style>
          .crypto_payment_wrapper{
            width: 100%;
            display: inline-block;
          }
          button#crypto_payment_btn {
              width: 100%;
              display:flex;
              margin-top: 15px !important;
              margin-bottom: 15px;
              background-color: #4550e6;
              color: #fff;
              justify-content: center;
              transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
              align-items: center !important;
              padding: 0.5rem 1rem;
              font-size: 1.25rem;
              border-radius: 0.3rem;
              font-weight: 500;
              border-color: #4550e6;
              text-transform: uppercase;
              
          }

          button#crypto_payment_btn:hover {
              background-color: #727aec;
              border-color: #4550e6;
              color: #fff;
          }

          button#crypto_payment_btn:focus {
              color: #fff;
              background-color: #727aec;
              border-color: #4550e6;
              box-shadow: 0 0 0 0.25rem rgb(13 57 253 / 25%);
              opacity: 1;
              outline: 0;
          }

      </style>
  <?php
}


function cryptoalgo_payment_button_html(){
   global $product;
    if(!is_product_can_be_buy_with_crypto_algo($product)){
        return ;
    }
      ?>
      <div class="crypto_payment_wrapper">
        <button id="crypto_payment_btn" type="button">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:v="https://vecta.io/nano" width="40" viewBox="0 0 180 112.257" fill-rule="evenodd" height="24"><path xmlns="http://www.w3.org/2000/svg" d="M132.622 104.587L121.29 82.473 109.969 60.38 93.683 28.599l-11.888-23.2h0A9.92 9.92 0 0 0 72.963 0H60.241c-3.723 0-7.134 2.084-8.832 5.398L.58 104.585c-.837 1.633-.763 3.583.194 5.149s2.66 2.519 4.495 2.519h18.19l36.552-71.328a7.41 7.41 0 0 1 13.185 0l9.968 19.451 11.316 22.08 15.269 29.794h18.19c1.834 0 3.537-.954 4.493-2.52s1.03-3.515.193-5.148l-.004.002z" fill-rule="evenodd" clip-rule="evenodd" fill="currentColor" class="ap-lg"></path><path d="M116.725 5.4H89.766l11.888 23.2h17.158c8.768.008 15.872 7.116 15.876 15.884s-7.095 15.882-15.863 15.897h-.885l10.513 20.517a38.07 38.07 0 0 0 8.898-4.129 38.65 38.65 0 0 0 18.007-32.694h0c-.001-21.343-17.29-38.652-38.634-38.677h-.002zM74.546 60.38H62.877l-.061-.047-26.347 51.923h26.033L77.699 82.31h5.2l2.659.034-11.01-21.964z" fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" class="ap-md"></path><path d="M94.478 82.462l-11.316-22.08h-8.613l11.012 21.964z" fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" class="ap-sm"></path></svg>
            <span>Pay With DGL/ALGO</span>
        </button>
     </div>


  <?php
}








?>