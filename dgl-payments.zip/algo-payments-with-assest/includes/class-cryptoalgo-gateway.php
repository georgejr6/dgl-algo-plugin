<?php

/**
 * CryptoAlgo Gateway
 *
 * @class CryptoAlgo_Gateway
 * @extends WC_Payment_Gateway
 * @version 1.0.0
 * @package WooCommerce/Classes/Payment
 */
class CryptoAlgo_Gateway extends WC_Payment_Gateway {

    public $app;

    public function __construct() {
        $this->id = "woocommerce-gateway-cryptoalgo";
        $this->has_fields = false;

        $this->configure_method();

        $this->init_settings();
        $this->init_form_fields();

        $this->title = $this->settings['title'];
        $this->description = $this->settings['description'];
        $this->wallet = $this->settings['wallet'];
        $this->assest = $this->settings['assest'];
        $this->assest_unit = $this->settings['unit'];
        $this->algo_enabled = $this->settings['algo_enabled'];
    }

    public function configure_method() {
        
        $this->method_title = "Crypto Gateway";
        $this->method_description = "Pay with Algo";
        $this->icon = plugins_url('/public/images/icon.png', __DIR__ );
        return;
    }


    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title' => __( 'Enable/Disable', 'cryptoalgo' ),
                'type' => 'checkbox',
                'label' => __( 'Enable Crypto Gateway', 'cryptoalgo' ),
                'default' => 'false'
            ),
            'title' => array(
                'title' => __( 'Title', 'cryptoalgo' ),
                'type' => 'text',
                'description' => __( 'This controls the title which the user sees during checkout.', 'cryptoalgo' ),
                'default' => __( 'Pay with Algo', 'cryptoalgo' ),
                'desc_tip'      => true,
            ),
            'description' => array(
                'title' => __( 'Customer Message', 'cryptoalgo' ),
                'type' => 'textarea',
                'default' => ''
            ),
            'wallet' => array(
                'title' => __("Your Wallet Address", "cryptoalgo"),
                'type' => 'text',
                'default' => ''
            ),
            'assest' => array(
                'title' => __("Assest Id", "cryptoalgo"),
                'type' => 'text',
                'default' => ''
            ),
            'unit' => array(
                'title' => __("Assest Unit", "cryptoalgo"),
                'type' => 'text',
                'default' => 'DGL'
            ),
            'algo_enabled' => array(
                'title' => __( 'Enable Algo', 'cryptoalgo' ),
                'type' => 'checkbox',
                'label' => __( 'Enable Algo Crypto', 'cryptoalgo' ),
                'default' => 'false'
            )
            
        );
    }
   // Print Html in the Admin Panel of Payment
    public function admin_options() {
      
        ?>
         <h2><?php echo esc_attr($this->method_title); ?></h2>
         <hr />
        
         <table class="form-table">
         <?php $this->generate_settings_html(); ?>
         </table>
         <?php
    }

    public function process_payment( $order_id ) {

        $order = new WC_Order($order_id); 
                        
               
		if ( $order->get_total() > 0 ) {
         
          return $this->finalise_payment($order);

     
		} else {
			$order->payment_complete();

            $order->add_order_note( __('Payment successfully completed:', 'cryptoalgo') ); 
		}
		// Remove cart.
		WC()->cart->empty_cart();
        $order->save();

		// Return thankyou redirect.
		return array(
			'result'   => 'success',
			'redirect' => $this->get_return_url( $order ),
		);
        

        return 0;
    }

    function payment_failed_case($order, $txid){

        $order->update_status( 'failed', __( 'Payment error: txID: ' .$txid. ' ', 'woocommerce' ));
        wc_add_notice( "Something went wrong with your payment. Please try again." , 'error' );
        CryptoAlgo_Logger::debug('Transaction ID not Valid: ' .$txid. ' for order '. $order->get_id());
        // return wp_redirect(WC()->cart->get_checkout_url());
    

    }




    function finalise_payment($order) {
        if($_POST['cryptoalgo_option'] == 0){
            $this->assest_unit = '\$Algo';
            $this->assest = 0;
        }
         
        $transaction_id = $_POST['transaction_id'];
        $paid_token = $_POST['paid_token'];
        
        update_post_meta($order->get_id(), 'cryptoalgo_paid_token', $paid_token.' '.$this->assest_unit);

        update_post_meta($order->get_id(), 'cryptoalgo_token_unit', $this->assest_unit);
             
         if($transaction_id != null && !empty($transaction_id) && $transaction_id != "" && strlen($transaction_id) == 52){

              $order->add_order_note( __('Customer Has to Pay: '.$paid_token.' '.$this->assest_unit, 'cryptoalgo') );

               $api_url = 'https://algoindexer.algoexplorerapi.io/v2/transactions/'.$transaction_id;
               sleep(5);
               $response = wp_remote_get( $api_url, array('timeout'=> 45,) );
               
               
               if ( is_wp_error( $response )  OR  200 !== wp_remote_retrieve_response_code( $response ) ) {

                   CryptoAlgo_Logger::debug('Received Response '. $response);
                   return $this->payment_failed_case($order,$transaction_id);
               }

               if ( 200 === wp_remote_retrieve_response_code( $response ) ) {
                   $body = wp_remote_retrieve_body($response);
                   CryptoAlgo_Logger::debug('Received Response '. $body);
                   $body = json_decode( $body , true);
                 
                 
                   $valid_payment = CryptoAlgo_Validator::validate_payment($body['transaction'],$this->assest ,$order);
                 
                   if($valid_payment == true) {
                       
                        
                       // Complete payment
                       $order->payment_complete();
                       $order->reduce_order_stock();
                       // Remove cart
                       WC()->cart->empty_cart();
                       
           
                       // Add note
                       $order->add_order_note( __('Payment successfully completed: txId '. $transaction_id , 'cryptoalgo') );
           
                       CryptoAlgo_Logger::debug('Payment txId '. $transaction_id . ' for order '. $order->get_id() .' successfully completed');
                       		// Return thankyou redirect.
                              
                            return array(
                                'result'   => 'success',
                                'redirect' => $this->get_return_url( $order ),
                            );

                   }else{
                        // No valid payment, let's retry.
                       return $this->payment_failed_case($order,$transaction_id);

                   }
                     
               
               }
               
               
         }else{

              return $this->payment_failed_case($order,$transaction_id);

          }



       
    }

    function process_admin_options() {
        $post_data = $this->get_post_data();
        if(!empty($post_data) && isset($post_data['woocommerce_'. $this->id .'_enabled']) && $post_data['woocommerce_'. $this->id .'_enabled'] == true) {
            $errors = false;

            if(empty($post_data['woocommerce_'. $this->id .'_assest'])) {
                WC_Admin_Settings::add_error(__("Assest Id is necessary before activating Crypto Gateway.", "cryptoalgo"));
                $errors = true;
            }

            if(empty($post_data['woocommerce_'. $this->id .'_wallet'])) {
                WC_Admin_Settings::add_error(__("Wallet Address is necessary before activating Crypto Gateway", "cryptoalgo"));
                $errors = true;
            }

            if($errors == true) {
                unset($post_data['woocommerce_'. $this->id .'_enabled']);
                $this->set_post_data($post_data);
            }
        }



        return parent::process_admin_options();
    }

    function add_gateway_class( $methods ) {
        $currency = get_woocommerce_currency();
        

       
            $methods[] = 'CryptoAlgo_Gateway';
        

           return $methods;
    }


    public function payment_fields() {
 
     ?>

         <ul class="cryptoalgo_options">
            <li clas="wc_payment_method">
              <input data-unit="<?php echo $this->assest_unit; ?>" type="radio" id="cryptoalgo_option_assest" name="cryptoalgo_option" value="<?php echo $this->assest; ?>" checked="checked" >
              <label for="cryptoalgo_option_assest">
                <span>
                <!-- <svg xmlns="http://www.w3.org/2000/svg" xmlns:v="https://vecta.io/nano" width="40" viewBox="0 0 180 112.257" fill-rule="evenodd" height="24"><path xmlns="http://www.w3.org/2000/svg" d="M132.622 104.587L121.29 82.473 109.969 60.38 93.683 28.599l-11.888-23.2h0A9.92 9.92 0 0 0 72.963 0H60.241c-3.723 0-7.134 2.084-8.832 5.398L.58 104.585c-.837 1.633-.763 3.583.194 5.149s2.66 2.519 4.495 2.519h18.19l36.552-71.328a7.41 7.41 0 0 1 13.185 0l9.968 19.451 11.316 22.08 15.269 29.794h18.19c1.834 0 3.537-.954 4.493-2.52s1.03-3.515.193-5.148l-.004.002z" fill-rule="evenodd" clip-rule="evenodd" fill="currentColor" class="ap-lg"></path><path d="M116.725 5.4H89.766l11.888 23.2h17.158c8.768.008 15.872 7.116 15.876 15.884s-7.095 15.882-15.863 15.897h-.885l10.513 20.517a38.07 38.07 0 0 0 8.898-4.129 38.65 38.65 0 0 0 18.007-32.694h0c-.001-21.343-17.29-38.652-38.634-38.677h-.002zM74.546 60.38H62.877l-.061-.047-26.347 51.923h26.033L77.699 82.31h5.2l2.659.034-11.01-21.964z" fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" class="ap-md"></path><path d="M94.478 82.462l-11.316-22.08h-8.613l11.012 21.964z" fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" class="ap-sm"></path></svg> -->
                <img style="width: 34px;" src="<?php echo plugins_url('/public/images/icon.png', __DIR__ ) ?>" alt="" srcset="">
                Pay With <?php echo $this->assest_unit; ?>
               </span>
            </label>
            </li>
            <?php if($this->algo_enabled == "yes") {?>
            <li clas="wc_payment_method">
              <input data-unit="Algo" type="radio" id="cryptoalgo_option_assest_algo" name="cryptoalgo_option" value="0" >
              <label for="cryptoalgo_option_assest_algo">
                <span>
                Pay With $Algo 
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:v="https://vecta.io/nano"  viewBox="0 0 180 112.257" fill-rule="evenodd" ><path xmlns="http://www.w3.org/2000/svg" d="M132.622 104.587L121.29 82.473 109.969 60.38 93.683 28.599l-11.888-23.2h0A9.92 9.92 0 0 0 72.963 0H60.241c-3.723 0-7.134 2.084-8.832 5.398L.58 104.585c-.837 1.633-.763 3.583.194 5.149s2.66 2.519 4.495 2.519h18.19l36.552-71.328a7.41 7.41 0 0 1 13.185 0l9.968 19.451 11.316 22.08 15.269 29.794h18.19c1.834 0 3.537-.954 4.493-2.52s1.03-3.515.193-5.148l-.004.002z" fill-rule="evenodd" clip-rule="evenodd" fill="currentColor" class="ap-lg"></path><path d="M116.725 5.4H89.766l11.888 23.2h17.158c8.768.008 15.872 7.116 15.876 15.884s-7.095 15.882-15.863 15.897h-.885l10.513 20.517a38.07 38.07 0 0 0 8.898-4.129 38.65 38.65 0 0 0 18.007-32.694h0c-.001-21.343-17.29-38.652-38.634-38.677h-.002zM74.546 60.38H62.877l-.061-.047-26.347 51.923h26.033L77.699 82.31h5.2l2.659.034-11.01-21.964z" fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" class="ap-md"></path><path d="M94.478 82.462l-11.316-22.08h-8.613l11.012 21.964z" fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" class="ap-sm"></path></svg>
               
               </span>
              </label>
            </li>
            <?php } ?>
         </ul>
     
    
        <style>
            ul.cryptoalgo_options li::marker {display: none !important;color: transparent;}
           .cryptoalgo_options li input[type=radio]:first-child {
                border: 0;
                clip: rect(1px, 1px, 1px, 1px);
                -webkit-clip-path: inset(50%);
                clip-path: inset(50%);
                height: 1px;
                margin: -1px;
                overflow: hidden;
                padding: 0;
                position: absolute;
                width: 1px;
                word-wrap: normal !important;
            }
            .cryptoalgo_options li label{
            display: block !important;
            padding: 10px 0px;cursor: pointer;
            }


            .cryptoalgo_options li label::before {
                -webkit-font-smoothing: antialiased;
                -moz-osx-font-smoothing: grayscale;
                display: inline-block;
                font-style: normal;
                font-variant: normal;
                font-weight: normal;
                line-height: 1;
                font-family: "Font Awesome 5 Free";
                font-weight: 900;
                line-height: inherit;
                vertical-align: baseline;
                content: "";
                margin-right: 0.5407911001em;
                transition: color,ease,.2s;
            }

            .cryptoalgo_options li input[type=radio]:first-child:checked+label::before {
                content: "";
            }
            .cryptoalgo_options li label span {
                color: #4550e6;
                font-weight: 600;
                text-transform: uppercase;
                

            }
            ul.cryptoalgo_options svg{
                float: right; 
                width: 32px;
                }
                .payment_method_woocommerce-gateway-cryptoalgo [for="payment_method_woocommerce-gateway-cryptoalgo"] img{
                    max-height: unset !important;
                    width: 39px;
                }
                .cryptoalgo_options img{  max-height: unset !important; float: right; }
                .payment_method_woocommerce-gateway-cryptoalgo label{ width: 100%; }
        </style>

        <?php
            if ( $this->description ) {
                echo wpautop( wp_kses_post( $this->description ) );
            }
     
    }
   

    function payment_scripts() {

		if ( ! is_checkout() )
			return;

		wp_enqueue_style( 'wc-algopay', plugins_url( '/public/dist/style.css', dirname( __FILE__ ) ) );
		// wp_enqueue_style( 'wc-algopay2-css', plugins_url( '/public/dist/style2.css', dirname( __FILE__ ) ) );
        wp_enqueue_script( 'wc-algopay', plugins_url( '/public/dist/index.js', dirname( __FILE__ ) ),'','',true);
		wp_enqueue_script( 'wc-main', plugins_url( '/public/script.js', dirname( __FILE__ ) ),'','',true);
		
	}
     

    function  algo_paybutton(){
      echo '<input id="transaction_id" type="hidden" name="transaction_id" value="" >';      
      echo "<style>.walletconnect-modal__header img{ width:50px; }</style>";      
      echo '<div id="root" data-locale="en-us"></div>';
      

    }


//     function name_of_your_function( $posted_data) {

//     global $woocommerce;

//     // Parsing posted data on checkout
//     $post = array();
//     $vars = explode('&', $posted_data);
//     foreach ($vars as $k => $value){
//         $v = explode('=', urldecode($value));
//         $post[$v[0]] = $v[1];
//     }

//     // Here we collect chosen payment method
//     $payment_method = $post['payment_method'];

//     // Run custom code for each specific payment option selected
//     if ($payment_method == "paypal") {
//         // Your code goes here
//     }

//     elseif ($payment_method == "bacs") {
//         // Your code goes here
//     }

//     elseif ($payment_method == "stripe") {
//         // Your code goes here
//     }
// }

// add_action('woocommerce_checkout_update_order_review', 'name_of_your_function');


   function algo_payscript(){

        if($this->algo_enabled == "yes"){

            if(isset($_POST['post_data'])){
                
                $posted_data =  $_POST['post_data'];
                $post = array();
                $vars = explode('&', $posted_data);
                foreach ($vars as $k => $value){
                    $v = explode('=', urldecode($value));
                    $post[$v[0]] = $v[1];
                }

                if(isset($post['cryptoalgo_option']) && $post['cryptoalgo_option'] == 0){
                        
                    $this->assest =  0;
                    $this->assest_unit = '$Algo';
                }

            }
        }

        $total =   WC()->cart->total;
        
        $Crypto_price  =   get_exchange_rate_of_given_assest($total, $this->assest);       
        echo '<input id="" type="hidden" name="paid_token" value="'.$Crypto_price['price'].'" >';
        // echo '<input id="transaction_id" type="hidden" name="transaction_id" value="" >';
        $Crypto_price["price"] = $Crypto_price["price"] *1000000;
        //  $Crypto_price["price"] = 1;
        echo  '<script>
            window.details = {
                    amount: '.$Crypto_price["price"].',
                    note: "",
                    index:  '.$this->assest.' ,
                    recipient: "'.$this->wallet.'",
                    input: false,
                    backend_enable: true,
                    backend_url: "",
                    unit: "'.$this->assest_unit.'",
                    txid: "transaction_id",
                    };

            </script>';



   } 

 


   function cryptoalgo_cart_totals_order_total_html( $value ){
    $check_array = check_type_of_products_in_cart();

        if($check_array['c'] AND  $check_array['nc']){
            return $value;

        }
        if(!$check_array['c']  AND $check_array['nc'] ){

            return $value;
        
        }

    $total =   WC()->cart->total;
    $crpto_price = "";
    $DGL_price  =   get_exchange_rate_of_given_assest($total, $this->assest);
    if($DGL_price['status'] == 1){

        $crpto_price =   '<br><span> Or '.number_format($DGL_price['price'], 5, '.', '').' '.$this->assest_unit.'</span>';
    }

    if($this->algo_enabled  == "yes"){
        $Algo_price  =   get_exchange_rate_of_given_assest($total, 0);
        if($Algo_price['status'] == 1){

            $crpto_price .=   '<br><span> Or '.number_format($Algo_price['price'], 5, '.', '').' $Algo</span>';
        }

     }
      
     $value = '<strong>' . WC()->cart->get_total().$crpto_price.'</strong> ';
 
     // If prices are tax inclusive, show taxes here.
     if ( wc_tax_enabled() && WC()->cart->display_prices_including_tax() ) {
         $tax_string_array = array();
         $cart_tax_totals  = WC()->cart->get_tax_totals();
  
         if ( get_option( 'woocommerce_tax_total_display' ) === 'itemized' ) {
             foreach ( $cart_tax_totals as $code => $tax ) {
                 $tax_string_array[] = sprintf( '%s %s', $tax->formatted_amount, $tax->label );
             }
         } elseif ( ! empty( $cart_tax_totals ) ) {
             $tax_string_array[] = sprintf( '%s %s', wc_price( WC()->cart->get_taxes_total( true, true ) ), WC()->countries->tax_or_vat() );
         }
  
         if ( ! empty( $tax_string_array ) ) {
             $taxable_address = WC()->customer->get_taxable_address();
             /* translators: %s: country name */
             $estimated_text = WC()->customer->is_customer_outside_base() && ! WC()->customer->has_calculated_shipping() ? sprintf( ' ' . __( 'estimated for %s', 'woocommerce' ), WC()->countries->estimated_for_prefix( $taxable_address[0] ) . WC()->countries->countries[ $taxable_address[0] ] ) : '';
             $value .= '<small class="includes_tax">('
                         /* translators: includes tax information */
                         . esc_html__( 'includes', 'woocommerce' )
                         . ' '
                         . wp_kses_post( implode( ', ', $tax_string_array ) )
                         . esc_html( $estimated_text )
                         . ')</small>';
         }
     }
    
           
    return $value;
}


/**
 *  Adding Admin Product Tab Link
 */

    function cryptoalgo_create_product_tab_link($tabs) {
        $tabs['cryptoalgo_tab'] = array(
            'label' => 'Cryptoalgo Settings',
            'target' => 'cryptoalgo_tab_options',
            'class' => array(),
            'priority' => 65,
        );
        return $tabs;
    }

/**
 *  Adding Admin Product TAb Options
 */

    function cryptoalgo_show_product_tab_link_content() {
        global $woocommerce, $post;
        ?>
        <div id="cryptoalgo_tab_options" class="panel woocommerce_options_panel">
            <?php

                woocommerce_wp_checkbox( array(
                    'id'            => '_cryptoalgo_product',
                    'wrapper_class' => 'show_if_simple2',
                    'label'         =>  __( 'Accept '.$this->assest_unit.' At Checkout', 'cryptoalgo' ),
                    'description'   =>  __( 'This will restrict the payment Gatway for this product.', 'cryptoalgo' ),
                    'desc_tip'   =>  __( 'This will restrict the payment Gatway for this product.', 'cryptoalgo' ),
                    'default'       => 'no'
                ) );

                woocommerce_wp_checkbox( array(
                    'id'            => '_cryptoalgo_force',
                    'wrapper_class' => 'show_if_simple2',
                    'label'         =>  __( 'Force Crypto Payment', 'cryptoalgo' ),
                    'description'   =>  __( 'When this option is enabled customer can only pay with Crypto.', 'cryptoalgo' ),
                    'desc_tip'   =>  __( 'When this option is enabled customer can only pay with Crypto.', 'cryptoalgo' ),
                    'default'       => 'no'
                ) );

            ?>
        </div>
        <?php
    }


/**
 *  Saving Admin Product Crypto Settings TAb Options
 */

function cryptoalgo_save_product_tab_data($product_id){

    //   echo "<pre>";
    //   print_r($_POST);
    //   echo "<pre>";
    //  die();
    $keys = array(
        '_cryptoalgo_product',
        '_cryptoalgo_force',
    );
    
    foreach ($keys as $key) {

          $value = (isset( $_POST[$key] ) && $_POST[$key] == 'yes' ) ? 'yes' : 'no';
          update_post_meta($product_id, $key,$value); 

        
    }
}

function cryptoalgo_save_product_tab_data_2($product_id, $form_data){

    //   echo "<pre>";
    //   print_r($_POST);
    //   echo "<pre>";
    //  die();
    $keys = array(
        '_cryptoalgo_product',
        '_cryptoalgo_force',
    );
    
    foreach ($keys as $key) {

          $value = (isset( $form_data[$key] ) && $form_data[$key] == 'yes' ) ? 'yes' : 'no';
          update_post_meta($product_id, $key,$value); 

        
    }
}


/**
	 * This function is used to Add  custom Panel for cryptoalgo
     * 
     * 
     */


  function crypto_algo_add_wcmf_panel( $product_id, $product_type){
    global  $WCFM;

    ?>

    <div class="page_collapsible products_manage_cryptoalgo_settings simple virtual variable grouped external non- collapse-close" 
          id="wcfm_products_manage_form_cryptoalgo_settings">
          <label class="wcfmfa fa-snowflake"></label>Cryptoalgo Settings<span class=""></span>
    </div>

    <div class="wcfm-container simple virtual variable grouped external non-" >
            <div id="wcfm_products_manage_form_cryptoalgo_settings_expander" class="wcfm-content">
                <h2>Cryptoalgo Settings</h2>
                <div class="wcfm_clearfix"></div>
                <?php 
                $accept_assest = ( get_post_meta( $product_id, '_cryptoalgo_product', true ) == 'yes' ) ? 'yes' : 'no';
                $cryptoalgo_force = ( get_post_meta( $product_id, '_cryptoalgo_force', true ) == 'yes' ) ? 'yes' : 'no';
                $WCFM->wcfm_fields->wcfm_generate_form_field( 
                    apply_filters( 'wcfm_pm_custom_field', 
                    array( '_cryptoalgo_product' => array( 'label' => __( 'Accept '.$this->assest_unit.' At Checkout', 'wc-frontend-manager') , 
                                               'name' => '_cryptoalgo_product', 
                                               'type' => 'checkbox', 
                                               'class' => 'wcfm-checkbox wcfm_ele simple variable external grouped booking', 
                                               'label_class' => 'wcfm_title checkbox-title p_'.$product_id, 
                                               'value' => 'yes',
                                               'dfvalue' => $accept_assest, 
                                               'hints' => __( 'This will restrict the payment Gatway for this product.', 'wc-frontend-manager') ) ), 
                                                $product_id  ) );
                
                $WCFM->wcfm_fields->wcfm_generate_form_field( 
                    apply_filters( 'wcfm_pm_custom_field', 
                    array( '_cryptoalgo_force' => array( 'label' => __( 'Force Crypto Payment', 'wc-frontend-manager') , 
                                               'name' => '_cryptoalgo_force', 
                                               'type' => 'checkbox', 
                                               'class' => 'wcfm-checkbox wcfm_ele simple variable external grouped booking', 
                                               'label_class' => 'wcfm_title checkbox-title', 
                                               'value' => 'yes',
                                               'dfvalue' => $cryptoalgo_force, 
                                               'hints' => __( 'When this option is enabled customer can only pay with Crypto.', 'wc-frontend-manager') ) ), 
                                                $product_id  ) );                                
            
                
                
                ?>


            </div>
    </div>
                
   

   <!-- end collapsible CryptoAlgo Settings -->
   <?php
  }   


/**
 * 
 * Adding html in the order details admin page
 */
function show_customer_paid_amount_cryptoalgo($order_id){ 
    
      $token = get_post_meta($order_id ,'cryptoalgo_paid_token', true);
    if($token != ''){
    ?>
    
    <tr>
				<td class="label label-highlight"><?php esc_html_e( 'Net Payment', 'woocommerce' ); ?>:</td>
				<td width="1%"></td>
				<td class="total">
				<?php echo get_post_meta($order_id ,'cryptoalgo_paid_token', true); ?>
				</td>
			</tr>


<?php } 
  }


}



function cryptoalgo_woocommerce_get_order_item_totals_filter( $total_rows, $order, $tax_display ){
    // excl
    $order_id = $order->get_id();
    $unit =         get_post_meta($order_id,'cryptoalgo_token_unit', true);
    $paid_token  =   get_post_meta($order_id,'cryptoalgo_paid_token', true);
  
    if($unit != ''){
  
      $value = $total_rows['payment_method']['value']." with ". $unit;
      $total_rows['payment_method']['value'] = $value;
  
    }
  
    if( $paid_token != '')
     $total_rows['order_total']['value'] = $paid_token;
     
  
   
      // filter...
      return $total_rows;
  }





?>
