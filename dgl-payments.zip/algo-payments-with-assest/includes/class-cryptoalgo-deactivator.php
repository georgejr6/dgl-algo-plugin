<?php

class CryptoAlgo_Deactivator {

  public static function deactivate() {
      // Todo
  }

}


?>
