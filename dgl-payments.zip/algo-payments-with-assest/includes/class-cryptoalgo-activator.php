<?php

class CryptoAlgo_Activator {

  public static function activate() {
      // Todo
  }

}


?>
