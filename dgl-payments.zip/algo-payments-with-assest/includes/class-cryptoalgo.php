<?php

class CryptoAlgo {

    protected $loader;
    protected $gateway;
    protected $client;

    protected $plugin_name;

    protected $version;

    public function __construct() {
        $this->plugin_name = 'woocommerce-gateway-cryptoalgo';

        $this->version = '2.0.0';

        $this->load_dependencies();
        $this->set_locale();
    }

    public function load_dependencies() {
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/functions-helpers.php';
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-cryptoalgo-loader.php';
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-cryptoalgo-i18n.php';
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-cryptoalgo-gateway.php';
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-cryptoalgo-validator.php';
        

        // Utility
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/utility/class-cryptoalgo-logger.php';

        $this->loader = new CryptoAlgo_Loader();

        $this->init_gateway();
        // $this->init_currencies();
    }

    private function set_locale() {
        $plugin_i18n = new CryptoAlgo_i18n();
        $plugin_i18n->load_plugin_textdomain();
    }

    public function init_gateway() {
        $this->gateway = new CryptoAlgo_Gateway();

        $this->loader->add_action('woocommerce_payment_gateways', $this->gateway, 'add_gateway_class');
        $this->loader->add_action('wp_enqueue_scripts', $this->gateway, 'payment_scripts');
        $this->loader->add_action('woocommerce_review_order_after_payment', $this->gateway, 'algo_paybutton');
        $this->loader->add_action('woocommerce_review_order_before_submit', $this->gateway, 'algo_payscript');   
        $this->loader->add_action('woocommerce_update_options_payment_gateways_' . $this->plugin_name, $this->gateway, 'process_admin_options', 10, 1);

        $this->loader->add_action('woocommerce_cart_totals_order_total_html', $this->gateway, 'cryptoalgo_cart_totals_order_total_html', 20, 1);


	    $this->loader->add_action( 'woocommerce_product_data_tabs', $this->gateway, 'cryptoalgo_create_product_tab_link' );
	    $this->loader->add_action( 'woocommerce_product_data_panels', $this->gateway, 'cryptoalgo_show_product_tab_link_content' );
		$this->loader->add_action( 'woocommerce_process_product_meta', $this->gateway, 'cryptoalgo_save_product_tab_data', 10, 1 );
        $this->loader->add_action( 'after_wcfm_products_manage_meta_save', $this->gateway, 'cryptoalgo_save_product_tab_data_2', 80 , 2);



		$this->loader->add_action( 'woocommerce_admin_order_totals_after_total', $this->gateway, 'show_customer_paid_amount_cryptoalgo');

        // WCFM Modify
        if(class_exists('WCFM')){
        // $this->loader->add_filter( 'wcfm_product_manage_fields_general',$this->gateway ,'crypto_algo_add_new_general_fields', 9, 5 );
        
        $this->loader->add_filter( 'after_wcfm_products_manage_linked',$this->gateway ,'crypto_algo_add_wcmf_panel', 10, 2 );


        // $this->loader->add_filter( 'wcfm_product_tabs',$this->gateway ,'add_custom_tab_to_product',  10, 1 );
      


        // $this->loader->add_action( 'after_wcfm_products_manage_meta_save',$this->gateway, 'crypto_algo_save_new_field_values', 10, 2 );

        }


        add_filter( 'woocommerce_get_price_html', 'crypto_algo_change_product_price_display', 20, 2 );
        add_filter( 'woocommerce_cart_item_subtotal', 'crypto_algo_filter_woocommerce_cart_item_price', 20, 3 ); 

        add_action('woocommerce_before_cart', 'crypto_algo_notice');
        add_action('woocommerce_before_checkout_form', 'crypto_algo_notice', 5);

        add_filter( 'woocommerce_available_payment_gateways', 'is_cart_has_both_type_of_products_check_crypto' );

        add_filter( 'woocommerce_get_order_item_totals', 'cryptoalgo_woocommerce_get_order_item_totals_filter', 10, 3 ); 


     
        //  Payment  Button 


          add_action('wp_footer', 'cryptoalgo_javascript_footer');


          add_action('woocommerce_after_add_to_cart_quantity', 'cryptoalgo_payment_button_html', 5 );
  
        // http://localhost/dapp/checkout/?add-to-cart=40&quantity=1
 


        
        

    }
    

    public function init_currencies() {
       

        // $this->loader->add_action('woocommerce_currencies', $currencies, 'add_currencies', 10, 1);
        // $this->loader->add_action('woocommerce_currency_symbol', $currencies, 'add_currency_symbol', 10, 2);

        // $this->loader->add_filter('woocommerce_price_format', $currencies, 'change_currency_position', 10, 2);
        // $this->loader->add_filter('wc_get_price_decimals', $currencies, 'adjust_currency_decimals', 10, 1);
        // $this->loader->add_filter('woocommerce_price_trim_zeros', $currencies, 'trim_zeros_for_currency', 999, 1);
        // $this->loader->add_filter('formatted_woocommerce_price', $currencies, 'formatted_woocommerce_price', 10, 2);

    }

    public function run() {
    	$this->loader->run();
    }

    public function get_plugin_name() {
    	return $this->plugin_name;
    }

    public function get_loader() {
    	return $this->loader;
    }

    public function get_version() {
    	return $this->version;
    }

    public function get_client() {
        return $this->client;
    }
}


?>
